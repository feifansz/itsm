// const BASEURL = "http://43.139.217.41:80/ffapaas";
// const ENGINEBASEURL = "http://43.139.217.41:80/ff-apaas-engine";
// const FILEVIEW = "http://192.168.0.100:8181/onlinePreview?url=";
// const PLATFORM = "FBuilder";
// const BASEURLMOBILE = "http://43.139.217.41:80/ff-apaas-mobile"

// const BASEURL = "http://192.168.0.81:8080/ffapaas";
// const ENGINEBASEURL = "http://192.168.0.81:8080/ff-apaas-engine";
// const FILEVIEW = "http://192.168.0.81:8012/onlinePreview?url=";
// const PLATFORM = "FBuilder";
// const BASEURLMOBILE = "http://wx.afanbuild.com/ff-apaas-mobile";

// const BASEURL = "http://192.168.0.80:8080/ffapaas";
// const ENGINEBASEURL = "http://192.168.0.80:6161/ff-apaas-engine";
// const FILEVIEW = "http://192.168.0.81:8012/onlinePreview?url=";
// const PLATFORM = "FBuilder";
// const BASEURLMOBILE = "http://wx.afanbuild.com/ff-apaas-mobile";

// const BASEURL = "https://crm.afanbuild.com/platform";
// const ENGINEBASEURL = "https://crm.afanbuild.com/ff-apaas-engine";
// const FILEVIEW = "http://175.6.146.71:8012/preview/onlinePreview?url=";
// const PLATFORM = "FBuilder";
// const BASEURLMOBILE = "http://wxcrm.afanbuild.com/ff-apaas-mobile";
// const BASEURL = "http://app.4000052619.com/ffapaas";
// const ENGINEBASEURL = "http://app.4000052619.com/ff-apaas-engine";
const BASEURL = "http://192.168.86:8080/ffapaas";
const ENGINEBASEURL = "http://192.168.86:6161/ff-apaas-engine";
const FILEVIEW = "http://192.168.0.86:8012/onlinePreview?url=";
const PLATFORM = "FBuilder";
const BASEURLMOBILE = "http://wx.afanbuild.com/ff-apaas-mobile";

// const BASEURL = "https://app.afanbuild.com/ffapaas"
// const ENGINEBASEURL = "https://app.afanbuild.com/ff-apaas-engine"
// const FILEVIEW = "https://app.afanbuild.com/preview/onlinePreview?url=";
// const PLATFORM = "FBuilder";
// const BASEURLMOBILE = "http://wx.afanbuild.com/ff-apaas-mobile"

//敏行测试环境
// const BASEURL = "http://7.100.128.9:18090/ffapaas";
// const ENGINEBASEURL = "http://7.100.128.9:18090/ff-apaas-engine";
// const FILEVIEW = "http://7.100.128.9:18090/preview/onlinePreview?url=";
// const PLATFORM = "MINXING";//敏行
// const BASEURLMOBILE = "http://wx.afanbuild.com/ff-apaas-mobile"

//敏行生产环境
// const BASEURL = "http://215.40.89.1:10891/ffapaas";
// const ENGINEBASEURL = "http://215.40.89.1:10891/ff-apaas-engine";
// const FILEVIEW = "http://215.40.89.1:10891/preview/onlinePreview?url=";
// const PLATFORM = "MINXING";//敏行
// const BASEURLMOBILE = "http://wx.afanbuild.com/ff-apaas-mobile"

//微信公众号环境
// const BASEURL = "https://app.afanbuild.com/ffapaas";
// const ENGINEBASEURL = "https://app.afanbuild.com/ff-apaas-engine";
// const FILEVIEW = "https://app.afanbuild.com/preview/onlinePreview?url=";
// const PLATFORM = "MP-WEIXIN";
// const BASEURLMOBILE = "http://wx.afanbuild.com/ff-apaas-mobile"

//企业微信环境
// const BASEURL = "http://wxcp.afanbuild.com/ffapaas";
// const ENGINEBASEURL = "http://wxcp.afanbuild.com/ff-apaas-engine";
// const FILEVIEW = "https://app.afanbuild.com.com/preview/onlinePreview?url=";
// const PLATFORM = "CP-WEIXIN";
// const BASEURLMOBILE = "http://wxcp.afanbuild.com/ff-apaas-mobile"

//钉钉
// const BASEURL = "http://dd.afanbuild.com/ffapaas";
// const ENGINEBASEURL = "http://dd.afanbuild.com/ff-apaas-engine";
// const FILEVIEW = "https://app.afanbuild.com.com/preview/onlinePreview?url=";
// const PLATFORM = "DD";
// const BASEURLMOBILE = "http://dd.afanbuild.com/ff-apaas-mobile"


//飞书
// const BASEURL = "http://feishu.afanbuild.com/ffapaas";
// const ENGINEBASEURL = "http://feishu.afanbuild.com/ff-apaas-engine";
// const FILEVIEW = "https://app.afanbuild.com.com/preview/onlinePreview?url=";
// const PLATFORM = "FS";
// const BASEURLMOBILE = "http://feishu.afanbuild.com/ff-apaas-mobile"


//交银
// const BASEURL = "http://192.168.0.112:8080/ff-apaas-code";
// const ENGINEBASEURL = "http://192.168.0.112:6161/ff-apaas-engine";
// const FILEVIEW = "http://192.168.0.222:8012/onlinePreview?url=";
// const PLATFORM = "SSO-JYSLD";
// const BASEURLMOBILE = "http://wx.afanbuild.com/ff-apaas-mobile"

//crm
// const BASEURL = "https://crm.afanbuild.com/platform";
// const ENGINEBASEURL = "https://crm.afanbuild.com/ff-apaas-engine";
// const FILEVIEW = "http://175.6.146.71:8012/preview/onlinePreview?url='";
// const PLATFORM = "MP-WEIXIN";
// const BASEURLMOBILE = "http://wxcrm.afanbuild.com/ff-apaas-mobile";

//交银
// const APPKEY = "EQXR9QKW"
// const APPSECRET = "869BD19E4C96628435DFE79E88A890CB"
// const SIGNSOURCE  = "597E341887955BD5133C7637006F5102"
// 80
// const APPKEY = "YCRGRRAC"
// const APPSECRET = "f666cb36b041fd6bc80c05819af7fa56"
// const SIGNSOURCE = "1a61927f2c136973241fb8864de72847"
//86
const APPKEY = "5WAONECP"
const APPSECRET = "BFA0B0FAF6CF41C18B216CDBC4D3B08A"
const SIGNSOURCE = "3EC4CC45888B405C895960A097434ABA"
// 梁总
// const APPKEY = "G9HX76GD"
// const APPSECRET = "9573E68D4D165ECD82A19E3D8DE91F4F"
// const SIGNSOURCE = "AF5DB19B251C8B1838EA66EAB8BFD008"
//APP
// const APPKEY = "3D3TFOPL"
// const APPSECRET = "1E6EB910EB2011EDAD13000C29FB8BFF"
// const SIGNSOURCE = "1A10B16AEB2011EDAD13000C29FB8BFF"
//crm
// const APPKEY = "TP2JIMLR"
// const APPSECRET = "50BAE880EB1C11EDAD13000C29FB8BFF"
// const SIGNSOURCE = "315AC8A0EB1C11EDAD13000C29FB8BFF"
// 汇丰兴业焦煤
// const BASEURL = "http://124.165.237.22:9098/ffapaas";
// const ENGINEBASEURL = "http://124.165.237.22:9098/ff-apaas-engine";
// const FILEVIEW = "http://124.165.237.22:9002/onlinePreview?url=";
// const PLATFORM = "FBuilder";
// const BASEURLMOBILE = "http://wx.afanbuild.com/ff-apaas-mobile";
// const APPKEY = "VPJPHRFK"
// const APPSECRET = "E996A2CEE93CC7240BF5F249B8875F19"
// const SIGNSOURCE = "0206BD5FC24C4020BA8AED6957AD0E16"
// 邀请注册地址
// const INVITETOREGISTER = "http://wx.afanbuild.com";
// crm微信公众号邀请地址
const INVITETOREGISTER = "http://192.168.0.69:8080";

