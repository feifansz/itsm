
// #ifndef H5
// 86
// const BASEURL = "http://192.168.0.86:8080/ffapaas"
// const ENGINEBASEURL = "http://192.168.0.86:6161/ff-apaas-engine"
// const FILEVIEW = "http://192.168.0.86:8012/preview/onlinePreview?url=";
//app
const BASEURL = "https://app.afanbuild.com/ffapaas"
const ENGINEBASEURL = "https://app.afanbuild.com/ff-apaas-engine"
const FILEVIEW = "https://app.afanbuild.com/preview/onlinePreview?url=";
//汇丰兴业
// const BASEURL = "http://124.165.237.22:9098/ffapaas";
// const ENGINEBASEURL = "http://124.165.237.22:9098/ff-apaas-engine";
// const FILEVIEW = "http://124.165.237.22:9002/onlinePreview?url=";
const PLATFORM = "FBuilder";
const BASEURLMOBILE = "http://wx.afanbuild.com/ff-apaas-mobile";

// 86
// const APPKEY = "5WAONECP"
// const APPSECRET = "BFA0B0FAF6CF41C18B216CDBC4D3B08A"
// const SIGNSOURCE = "3EC4CC45888B405C895960A097434ABA"
// const INVITETOREGISTER = "http://wx.afanbuild.com";
// app
const APPKEY = "3D3TFOPL"
const APPSECRET = "1E6EB910EB2011EDAD13000C29FB8BFF"
const SIGNSOURCE = "1A10B16AEB2011EDAD13000C29FB8BFF"
const INVITETOREGISTER = "http://wx.afanbuild.com";
// 汇丰兴业焦煤
// const APPKEY = "VPJPHRFK"
// const APPSECRET = "E996A2CEE93CC7240BF5F249B8875F19"
// const SIGNSOURCE = "0206BD5FC24C4020BA8AED6957AD0E16"
// const INVITETOREGISTER = "http://192.168.0.69:8080";

global.BASEURL = BASEURL
global.ENGINEBASEURL = ENGINEBASEURL
global.FILEVIEW = FILEVIEW
global.PLATFORM = PLATFORM
global.BASEURLMOBILE = BASEURLMOBILE
global.APPKEY = APPKEY
global.APPSECRET = APPSECRET
global.SIGNSOURCE = SIGNSOURCE
global.INVITETOREGISTER = INVITETOREGISTER
// #endif
