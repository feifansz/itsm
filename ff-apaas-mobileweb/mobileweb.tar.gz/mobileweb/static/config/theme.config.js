export default {
	// app应用名称
	appName: '非凡',

	// 主题列表
	themeList: [{
			title: '灰色',
			name: 'gray',
			color: '#8497C4',
			tabList: [
				'/static/theme/tab/tab-home-gray.png',
				// '/static/theme/tab/tab-favorite-gray.png',
				// '/static/theme/tab/tab-delegation-gray.png',
				'/static/theme/tab/tab-all-gray.png',
				'/static/theme/tab/tab-my-gray.png',
			]
		},
		{
			title: '橙色',
			name: 'orange',
			color: '#F4AC3A',
			tabList: [
				'/static/theme/tab/tab-home-orange.png',
				// '/static/theme/tab/tab-favorite-orange.png',
				// '/static/theme/tab/tab-delegation-orange.png',
				'/static/theme/tab/tab-all-orange.png',
				'/static/theme/tab/tab-my-orange.png',
			]
		},
		{
			title: '蓝色',
			name: 'blue',
			color: '#3568DA',
			tabList: [
				'/static/theme/tab/tab-home-blue.png',
				// '/static/theme/tab/tab-favorite-blue.png',
				// '/static/theme/tab/tab-delegation-blue.png',
				'/static/theme/tab/tab-all-blue.png',
				'/static/theme/tab/tab-my-blue.png',
			]
		},
		{
			title: '红色',
			name: 'red',
			color: '#DC6241',
			tabList: [
				'/static/theme/tab/tab-home-red.png',
				// '/static/theme/tab/tab-favorite-red.png',
				// '/static/theme/tab/tab-delegation-red.png',
				'/static/theme/tab/tab-all-red.png',
				'/static/theme/tab/tab-my-red.png',
			]
		},
		{
			title: '绿色',
			name: 'green',
			color: '#008E69',
			tabList: [
				'/static/theme/tab/tab-home-green.png',
				// '/static/theme/tab/tab-favorite-green.png',
				// '/static/theme/tab/tab-delegation-green.png',
				'/static/theme/tab/tab-all-green.png',
				'/static/theme/tab/tab-my-green.png',
			]
		},
		{
			title: '紫色',
			name: 'purple',
			color: '#7950EA',
			tabList: [
				'/static/theme/tab/tab-home-purple.png',
				// '/static/theme/tab/tab-favorite-purple.png',
				// '/static/theme/tab/tab-delegation-purple.png',
				'/static/theme/tab/tab-all-purple.png',
				'/static/theme/tab/tab-my-purple.png',
			]
		}
	]
};
