// 后台API接口地址
window.BASEURL = "http://192.168.0.86:8080/ffapaas";

// 流程引擎接口地址
window.ENGINEBASEURL = "http://192.168.0.86:6161/ff-apaas-engine";

// 管理后台地址
window.PLATFORMURL = "https://crm.afanbuild.com/platform/";

window.ws="ws://192.168.0.86:8080/ffapaas/socket?Authorization="

// 文档管理文件预览地址
window.FILEVIEW = "http://192.168.0.86:8012/onlinePreview?url=";

// 邀请注册地址
window.invitetoregister = "http://192.168.0.86";

// 登录来源代码
window.sourceType = 0;
// PC端:0
// 微信公众号端:1
// 微信小程序端:2
// 企业微信端:3
// 钉钉:4

window.Filinginformation = {
  company: '深圳市非凡信息技术有限公司',//备案公司
  time: '2004',//年份
  filingnumber: ''//备案号
}
//登录框头部文字
window.logintitle = '企业数字化底座平台'
//注册框欢迎注册的产品名称
window.loginregtitle = '阿凡搭'
//重置密码联系客服电话
window.phone = "0755-82717701"
// 签名参数
window.APPKEY = "5WAONECP"
window.APPSECRET = "BFA0B0FAF6CF41C18B216CDBC4D3B08A"
window.SIGNSOURCE = "3EC4CC45888B405C895960A097434ABA"
